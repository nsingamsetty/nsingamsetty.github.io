import matplotlib.pyplot as plt
import os.path

#Builds the file path and gets the file
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory,'DATA.txt')
datafile = open(filename,'r')
data = datafile.readlines()

#Initialize lists
info = []

for line in data[1:]:
    state, d, g = line.split(',')
    point = [state, d, g]
    info.append(point)

datafile.close()
i = 0
fig, ax  = plt.subplots(1, 1)
while i < len(info):
    ax.annotate(info[i][0], xy=(int(float(info[i][1])),int(float(info[i][2]))), xytext=(int(float(info[i][1])),int(float(info[i][2]))),arrowprops=dict(facecolor='black', shrink=0.005),)
    i += 1
    ax.annotate
ax.set_title('Corrolation Between Drinking and Dropout Rates in Highschool')
ax.set_xlabel('%Students who Drink')
ax.set_ylabel('%Students who Graduate')
ax.set_xlim(50, 100)
ax.set_ylim(68, 89)
fig.show()